public abstract class Polygon implements Shape {
    protected Vector2D[] vertices;
}

